# MÉMOIRE : 06 — Roadmap Produit : Bilan des Sprints & Jalons Futurs

> **Projet** : Lou Ame Tay  
> **Date de création** : 2026-09-29  
> **Version** : 2.0.0  
> **Auteur** : Antigravity & Équipe Lou Ame Tay  

---

## 📅 Contexte historique
La feuille de route de Lou Ame Tay s'articule autour d'une montée en puissance graduelle : d'abord équiper les commerciaux d'outils de pointe (Sprints 1 à 3), puis déployer l'écosystème restaurant complet en salle et en cuisine.

---

## 🎯 Bilan des Sprints Réalisés (v2.0.0)

### ✅ Sprint 1 : Fonctionnalités Networking à Fort Impact
- **B3 — WhatsApp Intelligent** : Génération dynamique de messages contextualisés avec prénom du commercial, nom du prospect et formule consultée.
- **C3 — Témoignages & Preuves Sociales** : Section dynamique avec avis notés (0-10) et intégration de démo vidéo YouTube.
- **E1 — Parrainage Traçable (`?ref=UUID`)** : Détection automatique des filleuls avec attribution au commercial parrain.
- **E2 — Partage Multi-Canal** : Modal modal de partage rapide (QR, WhatsApp, SMS, Copie lien avec Toast).

### ✅ Sprint 2 : Kit Networking Complet & Exports Imprimeur
- **D1 — Téléchargement du Kit Networking ZIP** : Archive contenant vCard 3.0, QR Code PNG 1000px, Carte de visite PDF 85x55mm, signature email HTML et guide d'instructions.
- **D2 — Carte de Visite PDF 85x55mm** : Génération à la volée recto-verso 300 DPI prête pour l'imprimeur physique.
- **D3 — Signature Email HTML Table-Based** : Code HTML pur copiable en 1 clic compatible avec Gmail, Outlook et Apple Mail.

### ✅ Sprint 3 : Admin v2 (CRM Leads & Modération Avis)
- **Tableau de Bord CEO** : Compteurs en direct (Total commerciaux, cartes actives, leads, MRR estimé).
- **CRM Leads & Devis** : Suivi des opportunités avec calcul de score automatique (0-100), filtres et export CSV.
- **Modération des Avis** : Interface de publication/masquage des témoignages clients.
- **Correctif d'Équité Profil** : Bouton 👁️ ouvrant fidèlement chaque conseiller selon son UUID Supabase réel.

---

## 🚀 Jalons Futurs (Sprints 4, 5 & 6)

```
┌─────────────────────────────────┐     ┌─────────────────────────────────┐     ┌─────────────────────────────────┐
│     SPRINT 4 : FINTECH UEMOA    │ ──> │    SPRINT 5 : WALLET & HARDWARE │ ──> │   SPRINT 6 : MULTI-TENANT KDS   │
│  - Passerelle Wave Direct API   │     │  - Pass Apple Wallet (.pkpass)  │     │  - Back-office multi-resto      │
│  - Orange Money Merchant Push   │     │  - Google Wallet Pass           │     │  - KDS temps réel WebSocket     │
│  - Facturation automatique FCFA │     │  - Puces NFC encodées NTAG213   │     │  - Gestion stocks & ruptures    │
└─────────────────────────────────┘     └─────────────────────────────────┘     └─────────────────────────────────┘
```

### Sprint 4 (Q4 2026) : Intégration FinTech UEMOA
1. **Passerelle Wave Checkout API** : Règlement direct en 1 clic du montant de l'abonnement mensuel (15 000, 25 000 ou 35 000 FCFA).
2. **Orange Money Web Payment** : Support du paiement par OTP ou QR code Orange Money.
3. **Génération automatique de Factures Normalisées** : Émission de reçus légaux au format PDF conformes aux exigences fiscales sénégalaises.

### Sprint 5 (Q1 2027) : Wallet Pass & Cartes Physiques Connectées (NFC)
1. **Apple Wallet & Google Pay Pass** : Ajout de la carte digitale directement dans l'application Cartes de l'iPhone ou Android sans ouvrir de navigateur.
2. **Cartes Physiques PVC & Bois Gravé NFC** : Encodage de puces NFC NTAG213 pointant vers l'URL de la carte digitale pour un échange de contact sans contact physique.

### Sprint 6 (Q2 2027) : Portail Établissements & Déploiement KDS SaaS
1. **Espace Restaurateur Autonome** : Permettre à chaque gérant de restaurant de modifier sa carte des plats, ses photos et ses prix depuis son smartphone.
2. **Écran Cuisine KDS WebSocket** : Connexion temps réel entre les tables et l'écran de la brigade en cuisine via Supabase Realtime.

---

## 📊 Métriques Cibles à 12 Mois
- **Nombre de restaurants abonnés actifs** : 150 établissements (Axe Dakar - Thiès - Mbour).
- **MRR Cible** : 5 250 000 FCFA / mois (base moyenne Formule Xéweul).
- **Taux de rétention annuel** : > 90%.
